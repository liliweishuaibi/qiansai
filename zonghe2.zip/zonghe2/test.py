import time
from collections import deque
from cvs import *
from genericDetector import GenericDetector
import threading
import pyttsx3

import asyncio
import os
import edge_tts

async def say(text):
    tts = edge_tts.Communicate(text, voice="zh-CN-XiaoxiaoNeural")
    output_file = "output.mp3"
    await tts.save(output_file)
    # 用系统命令播放音频，确保你系统安装了 mpg321 或其他播放器
    os.system("mpg321 " + output_file)

#def say(text):
    #engine = pyttsx3.init()
    #engine.setProperty('rate', 180)  # 设置语速
    #engine.setProperty('voice', 'zh')  # 中文语音（平台需支持）
    #找到了 index 为 0 的中文语音
    #engine.setProperty('voice', voices[67].id)  # 使用 Mandarin 中文语音
    #engine.say(text)
    #engine.runAndWait()

def main():
    # 模型路径与阈值
    model_path = 'models/object_detection_mobile_object_localizer_v1_1_default_1.tflite'
    threshold = 0.5

    # 初始化检测模型
    detector = GenericDetector(model_path, threshold)

    # 打开摄像头
    cap = cvs.VideoCapture(-1)

    # 创建一个滑动窗口用于判断触发条件
    detection_window = deque(maxlen=10)
    quotient_list = []  # 存储最近6个宽高比
    last_result = None  # 防止重复播报
    already_triggered = False

    while True:
        frame = cvs.read()

        if frame is None:
            print("正在读取摄像头画面")
            time.sleep(1)
            continue

        # 获取检测结果
        detections = detector(frame)

        # 获取当前帧的尺寸（用于像素计算）
        height, width, _ = frame.shape

        # 处理最后一个检测框
        if detections:
            last_detection = detections[-1]
            bbox = last_detection.get('bounding_box')
            if bbox is not None and len(bbox) == 4:
                x1, y1, x2, y2 = bbox  # 归一化坐标（0~1）
                box_width = (x2 - x1) * width
                box_height = (y2 - y1) * height
                print(f"宽度: {box_width:.1f}px, 高度: {box_height:.1f}px")
                if box_height > 0:
                    quotient = box_width / box_height
                    print(f"宽高比: {quotient:.2f}")
                    quotient_list.append(quotient)
                    if len(quotient_list) > 6:
                        quotient_list.pop(0)

                    if len(quotient_list) == 6:
                        if all(q > 1.45 for q in quotient_list) and last_result != 'person':
                            text1 = "后方行人"
                            asyncio.run(say(text1))
                            last_result = 'person'
                        elif all(q < 1.25 for q in quotient_list) and last_result != 'car':
                            text = "后方来车"
                            asyncio.run(say(text))
                            last_result = 'car'
                        elif not all(q > 1.45 for q in quotient_list) and not all(q < 1.25 for q in quotient_list):
                            last_result = None
                else:
                    print("高度为0，跳过")
            else:
                print(f"检测框格式错误：{last_detection}")

        # 检测触发逻辑（原有）
        #detection_window.append(1 if detections else 0)
        #if len(detection_window) == 10:
            #if sum(detection_window) >= 6:
                #if not already_triggered:
                    #print("在最近10帧中有6帧检测到物体！")
                    #say(" 后 方 来 车 ")
                    #already_triggered = True
            #else:
                #already_triggered = False

        # 显示图像
        detection_img = detector.draw_detections(frame, detections)
        cvs.imshow(detection_img)

# 确保 main 被调用
if __name__ == "__main__":
    main()
