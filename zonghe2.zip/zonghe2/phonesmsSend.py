import android
import json

droid=android.Android()
droid.smsSend("10086","查话费")
print(droid.smsGetMessages(False,"inbox",json.loads('["_id","body"]')))