import pyttsx3

def say(text):
    engine = pyttsx3.init()
    engine.setProperty('rate', 180)  # 语速
    engine.setProperty('voice', 'zh')  # 尝试中文语音（因平台而异）
    engine.say(text)
    engine.runAndWait()

if __name__ == "__main__":
    say(" 后 方 来 车 ")

# simple_voice_alert.py
#import asyncio
#import os
#import edge_tts

# 播报语音函数
#async def say(text):
   # tts = edge_tts.Communicate(text, voice="zh-CN-XiaoxiaoNeural")
   # output_file = "output.mp3"
   # await tts.save(output_file)
   # os.system("mpg321 " + output_file)

# 主函数
#if __name__ == "__main__":
   # asyncio.run(say("后方有来车"))
