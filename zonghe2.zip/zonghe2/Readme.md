phoneCallNumber.py文件为Aidlux下电话工程
phonesmsSend.py文件为Aidlux下短信工程

代码参数详细含义见Aidlux官方文档
https://docs.aidlux.com/api/#/?id=%e7%9f%ad%e4%bf%a1
