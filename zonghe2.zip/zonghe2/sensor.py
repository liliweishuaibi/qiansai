# fall_detector.py（原始文件名建议改成这个，避免和主文件重名）
import android
import time
import json
import threading

def call_for_help():
    droid = android.Android()
    droid.startTrackingPhoneState()
    droid.phoneCallNumber('18863510628')
    print(droid.readPhoneState())
    droid.stopTrackingPhoneState()

def main():
    droid = android.Android()
    droid.startSensingTimed(1, 100)

    called = False  # 避免重复报警

    try:
        while True:
            data = droid.readSensors().result
            if isinstance(data, dict):
                pitch = abs(data.get('pitch'))
                if pitch is not None and abs(pitch) < 0.3 and not called:
                    print("摔倒")
                    called = True
                    threading.Thread(target=call_for_help).start()

                sensor_data = {
                    'sensor_values': data,
                    'callback_name': 'sensor_reading'
                }
                json_data = json.dumps(sensor_data)
                print(json_data)

            time.sleep(2)

    except KeyboardInterrupt:
        droid.stopSensing()
        print("停止传感器读取")
