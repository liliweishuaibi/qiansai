import time
from cvs import *
import numpy as np
import aidlite_gpu
aidlite=aidlite_gpu.aidlite()

threshold = 0.2

w=192
h=192
inShape =[1*w*h*3]
outShape= [1*100*4*4,1*100*4,1*100*4,1*4]
model_path='models/object_detection_mobile_object_localizer_v1_1_default_1.tflite'
print('gpu:',aidlite.ANNModel(model_path,inShape,outShape,4,0))

cap=cvs.VideoCapture(1)
while True:
    # image = cv2.imread('tiger_cat.jpg')
    image = cap.read()
    if image is None:
        continue
    img_height, img_width, _ = image.shape
    img = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    input_tensor = cv2.resize(img, (w,h))
    input_tensor = input_tensor[np.newaxis,:,:,:]   
    aidlite.setInput_Int8(input_tensor,w,h)
    start_time = time.time()
    aidlite.invoke()
    t = (time.time() - start_time)
    print('elapsed_ms invoke:',t*1000)
    
    boxes = aidlite.getOutput_Float32(0).reshape(100,4)
    classes = aidlite.getOutput_Float32(1)
    scores = aidlite.getOutput_Float32(2)
    num_objects = int(aidlite.getOutput_Float32(3))
    for i in range(num_objects):
        if scores[i] >= threshold:
            y1 = (img_height * boxes[i,0]).astype(int)
            y2 = (img_height * boxes[i,2]).astype(int)
            x1 = (img_width * boxes[i,1]).astype(int)
            x2 = (img_width * boxes[i,3]).astype(int)
            cv2.rectangle(image, (x1, y1), (x2, y2), (0,0,255), 5)
    # cv2.imwrite('test.jpg', image)
    cvs.imshow(image)


