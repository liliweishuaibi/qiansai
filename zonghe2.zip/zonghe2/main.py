# main.py
import http.client
import json
import asyncio
import os
import edge_tts
from one import sasr_example  # 用户语音输入模块

# 语音播报函数
async def say(text):
    tts = edge_tts.Communicate(text, voice="zh-CN-XiaoxiaoNeural")
    output_file = "output.mp3"
    await tts.save(output_file)
    os.system("mpg321 " + output_file)

# 主流程函数
def main():
    # 1. 获取用户输入
    question = sasr_example().replace("。", "")

    # 2. DeepSeek API 请求
    conn = http.client.HTTPSConnection("api.deepseek.com")
    headers = {
        "Authorization": "Bearer sk-eb2f2b8a37c74925ae2de08545528ea0",  # 你的 API Key（建议通过环境变量读取）
        "Content-Type": "application/json"
    }

    payload = json.dumps({
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "你是一个有用的助手"},
            {"role": "user", "content": question}
        ]
    })

    conn.request("POST", "/v1/chat/completions", body=payload, headers=headers)
    response = conn.getresponse()
    result = response.read().decode("utf-8")
    dict_data = json.loads(result)

    try:
        answer = dict_data["choices"][0]["message"]["content"]
    except KeyError:
        print("API 调用失败，返回数据:", dict_data)
        answer = "API 调用失败，请检查 API Key 或请求格式！"

    # 文本清理
    answer = answer.replace("<br>", "").replace("℃", "摄氏度").replace("~", "到").replace("-", " ").replace("*", " ")
    print(answer)

    # 播放语音
    asyncio.run(say(answer))
