# main.py
import threading
import sensor
import main  # 你原来的 main 脚本
import test  # 新加入的目标检测模块

# 创建线程对象
t1 = threading.Thread(target=sensor.main)         # 线程1：传感器
t2 = threading.Thread(target=main.main)             # 线程2：其他主功能
t3 = threading.Thread(target=test.main)             # 线程3：目标检测

# 启动所有线程
t1.start()
t2.start()
t3.start()

# 等待线程结束（可选，适用于阻塞主线程直到所有线程完成）
t1.join()
t2.join()
t3.join()
