import android

droid=android.Android()
droid.startTrackingPhoneState()
droid.phoneCallNumber('18863510628')
print(droid.readPhoneState())
droid.stopTrackingPhoneState()

