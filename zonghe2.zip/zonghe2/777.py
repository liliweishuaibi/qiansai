from jnius import autoclass
from time import sleep

PythonActivity = autoclass('org.kivy.android.PythonActivity')
Context = autoclass('android.content.Context')
CameraManager = PythonActivity.mActivity.getSystemService(Context.CAMERA_SERVICE)
camera_id = CameraManager.getCameraIdList()[0]

CameraManager.setTorchMode(camera_id, True)
print("🔦 手电筒已打开")
sleep(5)

CameraManager.setTorchMode(camera_id, False)
print("🔕 手电筒已关闭")